-- INSTRUCTIONS --

If you are using Unity and want to get up an running right away you can open the "RPG Environment.unitypackage" which also comes with an Example Scene.

If not look under the "Models" folder.

The "Models" folder contains the model files along with the corresponding textures.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)